<?php

return [
	/*
     * Table name for followers records.
     */
	'relation_table' => 'user_follower',
];
