<h3>{{ $library->title }}</h3>
<hr>
{!! $library->description !!}