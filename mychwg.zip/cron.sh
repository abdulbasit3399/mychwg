#!/bin/sh
/usr/bin/php /home/u431718007/public_html/artisan schedule:run 1>> /dev/null 2>&1